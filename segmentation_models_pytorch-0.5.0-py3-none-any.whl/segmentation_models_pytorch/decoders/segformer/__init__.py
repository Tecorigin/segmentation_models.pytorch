from .model import Segformer

__all__ = ["Segformer"]
