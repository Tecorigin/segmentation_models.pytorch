from .model import PSPNet

__all__ = ["PSPNet"]
