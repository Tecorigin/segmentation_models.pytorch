from .model import MAnet

__all__ = ["MAnet"]
